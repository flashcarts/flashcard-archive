					lfnNameUnicode[0] = 0;
