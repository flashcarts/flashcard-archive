
#ifndef _console_h
#define _console_h

#ifdef __cplusplus
extern "C" {
#endif

extern void _consolePrint(const char* s);
//extern __attribute__ ((format(printf,1,2))) void _consolePrintf(const char* format, ...);
extern void _consolePrintf(const char* format, ...);

#ifdef __cplusplus
}
#endif

#endif
