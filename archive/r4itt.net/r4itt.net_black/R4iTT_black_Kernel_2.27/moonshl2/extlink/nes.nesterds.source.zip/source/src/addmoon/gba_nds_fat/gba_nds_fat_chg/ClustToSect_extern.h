
u32 FAT_ClustToSect_extern(u32 m)
{
  return(FAT_ClustToSect(m));
}

