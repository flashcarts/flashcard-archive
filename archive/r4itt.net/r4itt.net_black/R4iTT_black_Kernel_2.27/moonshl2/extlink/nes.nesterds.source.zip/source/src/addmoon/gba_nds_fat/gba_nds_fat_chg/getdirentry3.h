				lfnNameUnicode[(lfn.ordinal & ~LFN_END) * 13] = 0;	// Set end of lfn to null character
