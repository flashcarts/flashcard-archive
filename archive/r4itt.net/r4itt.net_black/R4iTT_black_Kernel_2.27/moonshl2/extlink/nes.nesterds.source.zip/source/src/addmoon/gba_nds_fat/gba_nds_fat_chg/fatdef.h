static u16 fatDumpBuffer[0x10000];
