
#include <nds.h>

#include "_console.h"
#include "_const.h"

void ShowLogHalt(void)
{
  REG_IME=0;
  _consolePrintf("Halted.\n");
  while(1);
}

