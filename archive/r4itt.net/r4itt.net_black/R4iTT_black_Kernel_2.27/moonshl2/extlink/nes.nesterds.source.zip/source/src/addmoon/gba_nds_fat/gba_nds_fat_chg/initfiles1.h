lfnNameUnicode[i] = 0;
