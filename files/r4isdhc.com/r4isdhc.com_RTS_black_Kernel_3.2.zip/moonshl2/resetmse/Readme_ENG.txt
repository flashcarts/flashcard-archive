If you copy a firmware reset NDS file compatible with your flashcart into this folder, you will be able to exit MoonShell2 back into the firmware.

I have discontinued development on the complicated structure of MoonShell. The MSE structure isn't retained in VRAM.
It just loads the 'flashcartname.nds' file.  For the flashcart name, please designate it as the flashcart's unique DLDI ID (for example, M3 DS Real would be M3DS.nds).

ex:
SCDS.nds => for SuperCard DS One
CEVO.nds => for CycloDS
DLMS.nds => for DSLink
R4TF.nds => for R4

~Translated by Densetsu3000
