
Esta pasta cont�m os arquivos da guia "Acess�rios".
Voc� pode ter at� 5 arquivos .NDS nesta pasta.
Voc� pode excluir o conte�do desta pasta, apenas n�o exclua a pr�pria pasta "launch".

~Traduzido por Axel-MaV