﻿사용하시는 닥터와 호환되는 펌웨어 리셋용 NDS 파일을 이 곳에 두시면 문쉘2에서 소프트 리셋 기능을 사용하실 수 있습니다.

복작한 구조의 문쉘 개발을 중단했습니다. MSE 구조는 VRAM 에 유지되지 않습니다.
단지 '사용하는 닥터이름.nds' 파일을 불러들입니다.  사용할 닥터이름에는 닥터의 고유 DLDI ID
(예를 들어 M3 DS Real 의 경우 M3DS.nds) 식으로 만들어 주세요.

~영문번역 Densetsu3000
gbatemp.net
한글번역 체리체리(다음 NINTENDO-DS 카페)
http://cafe.daum.net/NINTENDODS
===============================
이번 배포에 포함된 소프트 리셋용 파일:
SuperCard DSOne	SCDS.nds	업로더 Boriar
CycloDS		CEVO.nds	제작자 알수 없음
DSLink		DLMS.nds	제작자 Rudolph
R4		R4TF.nds	제작자 Rudolph

그가 만든 소프트리셋에 관한 Rudolph 의 글:
http://kotei.blog.so-net.ne.jp/2009-02-01-1