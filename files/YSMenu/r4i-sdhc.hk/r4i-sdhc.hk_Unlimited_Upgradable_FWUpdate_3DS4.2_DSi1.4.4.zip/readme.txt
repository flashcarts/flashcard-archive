1. Extract all files to root of SD
2. Load cart and run 3DS42.nds