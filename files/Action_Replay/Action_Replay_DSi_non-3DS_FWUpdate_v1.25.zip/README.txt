THIS IS SPECIFICALLY FOR DSi ACTION REPLAY CARTS, NOT DSi + 3DS MODELS!!!

1: Installing CodeManager
Install "ActionReplayDsiCodeManagerSetup-2018.exe"
Run "Action Replay DSi Code Manager"
Connect your Action Replay cart
If your cart is not bricked, back up your codes!

2: Unbricking the AR (i.e. "Red Screen of Death")
Click on the Code Manager icon in the top left
Press About Action Replay DSi Code Manager
Press "Reset Hardware" accept any warnings and wait.

3: Updating the AR
Install "ARDSi-FirmwareUpdate-1.4.5.exe"
Run "DSi Compatible Action Replay Firmware Update"
Connect your Action Replay cart
Press "Start" and wait.