THIS IS SPECIFICALLY FOR THE SUPERCARD RUMBLE/SUPERCARD LITE RUMBLE!!!

Upgrading the firmware: (Read entirely before proceeding)
Hold L+R while launching your cart to enter test mode, press A until you see version information.
>You will need to upgrade through every version in order, starting with the next one from your current version.
 (so if your cart is on 1.63, you start with 1.7, if your cart is on 1.7, you start with 1.81, etc.)
>1.80 and 1.83 are missing, this is fine.
>With 1.84, you will also need to copy dldi.scp to your SD-Card.
Take the next version update from the FIRM folder, rename it to "UPGRADE.scu" and place it on your SD-Card.
Launch your Cart, verify that the versions listed differ, and press START.
Wait for the update to finish (it will return to the main menu).
Power off your console, put the SD-Card back in your PC, and repeat for the next version.
Once you are on 1.85, remove "UPGRADE.scu" from your SD-Card. Done!

Using the companion patcher:
Install "setuprumbleV271en.exe"
Run "Super Card"
Go to "Options", set "Out Path" to where you want your patched ROMs to be placed.
Return to "Game List", click "Add" and select your ROM.
You can double-click the ROM in the list to manage patches. Usually defaults are fine.
Press "Out" and wait until a "Complete" dialogue pops up.
Copy the files from the "Out Path" you set to your SD-Card. Done!

Common? Issues:
You need a PassCard (or Slot-1 flashcart capable of booting Slot-2 in NDS mode) to use this cart.
GBA games are not supported, the hardware needed is replaced by the (mediocre) rumble hardware.
You need a non-SDHC/SDXC card (2GB or less) for this cart.
You must always patch your ROMs for this cart.