This FWUpdate will support 3DS 4.5 and DSi 1.4.5.

1. Extract the `.nds` to root of SD.
2. Load cart and run the `.nds` file.