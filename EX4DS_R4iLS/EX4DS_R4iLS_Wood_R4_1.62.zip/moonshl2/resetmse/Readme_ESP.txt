﻿
Para aprovechar las ventajas del reinicio (reset), se debe añadir el archivo correspondiente a tu flashcart.

He abandonado el complejo método de Moonshell antiguo. La estructura de MSE ya no está en la VRAM.

Ahora es un archivo nds que es ejecutado. El archivo debe tener un nombre del tipo "nombre_de_flashcart.nds".

ejemplo:

SCDS.nds => SuperCard DS One
CEVO.nds => CycloDS
DLMS.nds => DSLink
R4TF.nds => R4

Nota: El nombre que se utiliza es el que está definido en la cabecera de sus correspondientes DLDI.

~Traducido por Boriar