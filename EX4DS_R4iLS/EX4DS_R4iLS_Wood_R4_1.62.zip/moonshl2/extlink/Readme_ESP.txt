﻿
Le permite asociar una aplicación externa con una extensión de archivo.
Por favor, no borre esta carpeta incluso si usted no utiliza esta función.

El nombre de la extensión se define con el nombre del archivo que los ejecutará.
Por ejemplo, si el archivo es ipk.nds se encuentra en la carpeta, tan pronto como se ejecute un archivo con la extensión IPK, éste se le pasará a ipk.nds y lo ejecutará. Cuando la extensión ya está asociado con un plug-in interno será la aplicación de esta carpeta la que tendrá prioridad (mp3.nds, jpg.nds, etc.)

Si la aplicación no es compatible con esta función, se ejecuta el archivo asociado, pero no abrirá el archivo deseado.
Por ejemplo, si coloca ReinMoon.nds en esta carpeta y cambia el nombre a sav.nds, al abrir un archivo SAV, ReinMoon se ejecutará independientemente del archivo SAV seleccionado.

Crear una aplicación compatible con la asociación para la ampliación no es difícil (traté de mantener las cosas simples).
Véase el archivo "moonshl2_extlink_for_developer.txt" (previsto para más tarde) para más información.
Cómo volver a Moonshell 2 desde un homebrew también se describirá (esto es quizás un poco difícil).

~Traducido por Boriar